# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table person (
  id                            bigint auto_increment not null,
  firstname                     varchar(255),
  age                           integer not null,
  constraint pk_person primary key (id)
);

create table personne (
  id                            bigint auto_increment not null,
  nom                           varchar(255),
  prenom                        varchar(255),
  age                           integer not null,
  constraint pk_personne primary key (id)
);


# --- !Downs

drop table if exists person;

drop table if exists personne;

